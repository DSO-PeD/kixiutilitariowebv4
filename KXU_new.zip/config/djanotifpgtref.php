<?php

return [
    'callback_access_key' => env('PAYMENT_CALLBACK_ACCESS_KEY'),
];
