<template >
    <div class="flex ">

        <div class="flex-1 min-h-screen bg-gray-100">

            <main class="p-4">
                <slot />
            </main>
        </div>
    </div>
</template>
