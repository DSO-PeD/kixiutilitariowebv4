<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ComissoesMaturidadeModel extends Model
{
    //
     protected $table = 'comissoesmaturidade';
}
